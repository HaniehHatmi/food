﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Web.UI.HtmlControls;
using System.Web.Configuration;

using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;

using System.IO;

namespace fasfood
{
    public partial class order : System.Web.UI.Page
    {
        string cs = WebConfigurationManager.ConnectionStrings["all"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {


            string sid = Request.QueryString["id"];

            SqlConnection conn = new SqlConnection(cs);
            SqlCommand cmd2 = new SqlCommand("select *  from orderr ", conn);
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            DataSet ds2 = new DataSet();

            try
            {
                conn.Open();
                da2.Fill(ds2);

            }
            finally
            {
                conn.Close();
            }

            if (!Page.IsPostBack)
            {

                if (ds2.Tables[0].Rows.Count != 0)
                {

                    fill_form();

                }
                else
                {
                    Form.InnerHtml = "سبد خرید شما خالی است... ";
                }


            }
        }


        void fill_form()
        {
            string sid = Request.QueryString["id"];

            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand("select *  from orderr", con);

            //cmd.Parameters.AddWithValue("@id", sid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable ds = new DataTable();

            try
            {
                con.Open();
                da.Fill(ds);

            }
            finally
            {
                con.Close();
            }
            for (int i = 0; i < ds.Rows.Count; i++)
            {
                HtmlGenericControl or = new HtmlGenericControl("div");
                or.Attributes["class"] = "or";

                HtmlImage img = new HtmlImage();
                img.Attributes["src"] = ds.Rows[i][4].ToString();
                img.Attributes["class"] = "img";

                HtmlGenericControl h = new HtmlGenericControl("h1");
                h.InnerHtml = ds.Rows[i][1].ToString();
                h.Attributes["class"] = "title";

                HtmlGenericControl com = new HtmlGenericControl("div");
                com.Attributes["class"] = "comb";
                com.InnerHtml = ds.Rows[i][3].ToString();

                HtmlGenericControl sp = new HtmlGenericControl("span");
                sp.Attributes["class"] = "pr";
                sp.InnerHtml = ds.Rows[i][2].ToString() + " تومان";

                HtmlGenericControl nafar = new HtmlGenericControl("div");
                nafar.Attributes["class"] = "nafar";
                nafar.InnerHtml = ds.Rows[i][5].ToString();

                HtmlGenericControl number = new HtmlGenericControl("div");
                number.Attributes["class"] = "number";

                HtmlGenericControl num = new HtmlGenericControl("div");
                num.Attributes["class"] = "num";
                num.InnerHtml = "تعداد";

                HtmlGenericControl count = new HtmlGenericControl("span");
                count.Attributes["class"] = "count";
                count.InnerHtml = ds.Rows[i][6].ToString();

                HtmlGenericControl sum = new HtmlGenericControl("div");
                sum.Attributes["class"] = "pr";
                sum.InnerHtml = ds.Rows[i][7].ToString() + "  تومان";

                HtmlGenericControl del = new HtmlGenericControl("div");
                del.Attributes["class"] = "close";

                //HtmlAnchor anc = new HtmlAnchor();
                ////anc.Attributes["href"] = "order.aspx?id=" + ds.Rows[i][0].ToString();
                //anc.Attributes["id"] = ds.Rows[i][0].ToString();
                //anc.InnerHtml = "hh";

                HtmlInputSubmit bt = new HtmlInputSubmit();
                //bt.ServerClick -= dell;
                //bt.ServerClick += new EventHandler(dell);
                //bt.Click += bt_ServerClick;

                bt.Attributes["href"] = "menu.aspx?id=" + ds.Rows[i][0].ToString();
                bt.Value = "حذف";


                //anc.Controls.Add(bt);
                del.Controls.Add(bt);

                number.Controls.Add(num);
                number.Controls.Add(count);

                or.Controls.Add(del);
                or.Controls.Add(img);
                or.Controls.Add(h);
                or.Controls.Add(com);
                or.Controls.Add(sum);

                or.Controls.Add(sp);
                or.Controls.Add(nafar);

                or.Controls.Add(number);

                orderMenu.Controls.Add(or);


            }
        }
    }

        protected void dell(object sender, EventArgs e)
        {

            string s = Request.QueryString["id"];

            SqlConnection con2 = new SqlConnection(cs);
            SqlCommand cmd2 = new SqlCommand("delete from orderr where id=@id", con2);

            cmd2.Parameters.AddWithValue("@id", s);

            try
            {
                con2.Open();
                cmd2.ExecuteNonQuery();
                Response.Redirect("order.aspx?id=" + s);
                Form.InnerHtml = "حذف موفقیت آمیز . . . ";
            }
            // catch { }
            finally
            {
                con2.Close();
            }
        }
    }

