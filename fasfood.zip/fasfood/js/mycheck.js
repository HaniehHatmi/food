﻿
    var pr = document.getElementById("pr");
    var val = parseInt(pr.value);
    var num = document.getElementById("num");
    var num2 = document.getElementById("num2");

 function mychek() {

             if (num.checked == true) {
                post= pr.value = val + 20000;
                 num2.disabled = false;
             }
         }
             function mychek2() {

                 if (num2.checked == true)
                 {
                     pr.value = val;
                     num.disabled = false;
                 }
             }

function ok() {
    var er = document.getElementById("er");
    er.style.display = "none";
}

         pos = 0;
         function gotop() {
             if (pos > -200) {
        pos = pos - 100;
                 gal.style.top = pos + "%";
             }
             else if (pos == -200) {
        pos = 0;
                 gal.style.top = pos + "%";
             }
         }