﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Web.UI.HtmlControls;
using System.Web.Configuration;

using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;

using System.IO;


public partial class menu : System.Web.UI.Page
{
    string cs = WebConfigurationManager.ConnectionStrings["all"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(cs);
        SqlCommand cmd = new SqlCommand("select * from pizza", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();

        SqlCommand cmd2 = new SqlCommand("select * from salad" , con);

        SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
        DataSet ds2 = new DataSet(); 
        
        SqlCommand cmd3 = new SqlCommand("select * from toast" , con);
        SqlDataAdapter da3 = new SqlDataAdapter(cmd3);
        DataSet ds3 = new DataSet();

        try
        {
            con.Open();
            da.Fill(ds);
            da2.Fill(ds2);
            da3.Fill(ds3);
        }
        finally
        {
            con.Close();
        }

        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {

            HtmlGenericControl com = new HtmlGenericControl("div");
            com.Attributes["class"] = "combination";
            com.InnerHtml = ds.Tables[0].Rows[i][3].ToString();


            HtmlGenericControl box = new HtmlGenericControl("div");
            box.Attributes["class"] = "box-menu";

            HtmlAnchor n = new HtmlAnchor();

            n.InnerHtml = ds.Tables[0].Rows[i][1].ToString();
            n.Attributes["href"] = "productt.aspx?id=" + ds.Tables[0].Rows[i][0].ToString();
            n.Attributes["class"] = "onvan";

            HtmlGenericControl mk = new HtmlGenericControl("div");
            mk.Attributes["class"] = "makhlot";

            HtmlImage img = new HtmlImage();
            img.Attributes["class"] = "img";
            img.Attributes["src"] = "img/" + ds.Tables[0].Rows[i][4].ToString();

            HtmlGenericControl pr = new HtmlGenericControl("div");
            pr.Attributes["class"] = "price";
            pr.InnerHtml = ds.Tables[0].Rows[i][2].ToString();

            HtmlGenericControl ad = new HtmlGenericControl("div");
            ad.Attributes["class"] = "add";
            ad.Attributes["title"] = "افزودن به سبر خرید";

            mk.Controls.Add(img);
            box.Controls.Add(mk);
            box.Controls.Add(n);
            box.Controls.Add(pr);
            box.Controls.Add(ad);
            box.Controls.Add(com);

            top.Controls.Add(box);
        }
        
        for (int a = 0; a < ds3.Tables[0].Rows.Count; a++)
        {

            HtmlGenericControl com = new HtmlGenericControl("div");
            com.Attributes["class"] = "combination";
            com.InnerHtml = ds3.Tables[0].Rows[a][3].ToString();

            HtmlAnchor n = new HtmlAnchor();

            n.InnerHtml = ds3.Tables[0].Rows[a][1].ToString();
            n.Attributes["href"] = "toast_pro.aspx?id=" + ds3.Tables[0].Rows[a][0].ToString();
            n.Attributes["class"] = "onvan";

            HtmlGenericControl box = new HtmlGenericControl("div");
            box.Attributes["class"] = "box-menu";

            HtmlGenericControl mk = new HtmlGenericControl("div");
            mk.Attributes["class"] = "makhlot";

            HtmlImage img = new HtmlImage();
            img.Attributes["class"] = "img";
            img.Attributes["src"] = "img/" + ds3.Tables[0].Rows[a][4].ToString();

            HtmlGenericControl pr = new HtmlGenericControl("div");
            pr.Attributes["class"] = "price";
            pr.InnerHtml = ds3.Tables[0].Rows[a][2].ToString();

            HtmlGenericControl ad = new HtmlGenericControl("div");
            ad.Attributes["class"] = "add";
            ad.Attributes["title"] = "افزودن به سبر خرید";

            mk.Controls.Add(img);
            box.Controls.Add(mk);
            box.Controls.Add(n);
            box.Controls.Add(pr);
            box.Controls.Add(ad);
            box.Controls.Add(com);

            center.Controls.Add(box);
        }


        for (int x = 0; x < ds2.Tables[0].Rows.Count; x++)
        {

            HtmlGenericControl sp = new HtmlGenericControl("div");
            sp.Attributes["class"] = "combination";
            sp.InnerHtml = ds2.Tables[0].Rows[x][3].ToString();


            HtmlGenericControl it = new HtmlGenericControl("div");
            it.Attributes["class"] = "box-menu";

            HtmlAnchor n = new HtmlAnchor();

            n.InnerHtml = ds2.Tables[0].Rows[x][1].ToString();
            n.Attributes["href"] = "salad_pro.aspx?id=" + ds2.Tables[0].Rows[x][0].ToString();
            n.Attributes["class"] = "onvan";

            HtmlGenericControl mk2 = new HtmlGenericControl("div");
            mk2.Attributes["class"] = "makhlot";

            HtmlImage im = new HtmlImage();
            im.Attributes["class"] = "img";
            im.Attributes["src"] = "img/" + ds2.Tables[0].Rows[x][4].ToString();

            HtmlGenericControl p = new HtmlGenericControl("div");
            p.Attributes["class"] = "price";
            p.InnerHtml = ds2.Tables[0].Rows[x][2].ToString();

            HtmlGenericControl add = new HtmlGenericControl("div");
            add.Attributes["class"] = "add";
            add.Attributes["title"] = "افزودن به سبر خرید";

            mk2.Controls.Add(im);
            it.Controls.Add(mk2);
            it.Controls.Add(n);
            it.Controls.Add(p);
            it.Controls.Add(add);
            it.Controls.Add(sp);

            botem.Controls.Add(it);



        }
    }
}


