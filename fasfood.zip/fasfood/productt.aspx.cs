﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Web.UI.HtmlControls;
using System.Web.Configuration;

using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;

using System.ComponentModel.DataAnnotations;



namespace fasfood
{
    public partial class productt : System.Web.UI.Page
    {
        string cs = WebConfigurationManager.ConnectionStrings["all"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand("select * from pizza", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();

            try
            {
                con.Open();
                da.Fill(ds);
                
            }
            finally
            {
                con.Close();
            }

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                HtmlGenericControl item = new HtmlGenericControl("div");
                item.Attributes["class"] = "item";

                HtmlImage img = new HtmlImage();
                img.Attributes["src"] = "img/" + ds.Tables[0].Rows[i][4].ToString();

                HtmlGenericControl sp = new HtmlGenericControl("span");
                sp.InnerHtml = ds.Tables[0].Rows[i][1].ToString();

                HtmlAnchor menu = new HtmlAnchor();
                menu.Attributes["class"] = "manu";
                menu.InnerHtml = "مشاهده منو";
                menu.Attributes["href"] = "productt.aspx?id=" + ds.Tables[0].Rows[i][0].ToString();

                HtmlGenericControl pr = new HtmlGenericControl("div");
                pr.Attributes["class"] = "price";
                pr.InnerHtml = ds.Tables[0].Rows[i][2].ToString();

                

                item.Controls.Add(img);
                item.Controls.Add(sp);
                item.Controls.Add(pr);
                item.Controls.Add(menu);

                otherproduct.Controls.Add(item);

            }
            string sid = Request.QueryString["id"];

            if (!Page.IsPostBack)
            {

                if (sid != null)
                {

                    fill_form();

                }
                else
                {
                    Form.InnerHtml = "داده نا موجود . . . ";
                }


            }
            //تعداد ایتم سبد خرید

            SqlCommand cmd2 = new SqlCommand("select * from orderr", con);
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            DataSet ds2 = new DataSet();

            try
            {
                con.Open();
                da2.Fill(ds2);


            }
            finally
            {

                con.Close();
            }
                var x = ds2.Tables[0].Rows.Count;

                HtmlGenericControl order = new HtmlGenericControl("div");
                order.Attributes["class"] = "count";
                order.InnerHtml = x.ToString();

                orderCount.Controls.Add(order);
            


        }


        protected void add(object sender, EventArgs e)
        {
            string sid = Request.QueryString["id"].ToString();

            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand("insert into orderr values(@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8)", con);


            int summ;
            int num1 = int.Parse(pr.Value);
            int num2 = int.Parse(number.Value);
            summ = num1 * num2;

            if (num.Checked)
            {
                num.Value = "یک نفره";
            }
            else
            {
                num.Value = "دو نفره";
            }

            cmd.Parameters.AddWithValue("@p1", onvan.InnerHtml);
            var x = cmd.Parameters.AddWithValue("@p2", pr.Value);
            cmd.Parameters.AddWithValue("@p3", comb.InnerHtml);
            cmd.Parameters.AddWithValue("@p4", img.Src);
            cmd.Parameters.AddWithValue("@p5", num.Value);
            cmd.Parameters.AddWithValue("@p6", number.Value);
            cmd.Parameters.AddWithValue("@p7", summ);
            cmd.Parameters.AddWithValue("@p8", 1);
            cmd.Parameters.AddWithValue("@id", sid);


            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                er.Style["display"] = "block";

            }
            // catch  {       }
            finally
            {

                con.Close();

            }

        }













void fill_form()
        {
            string sid = Request.QueryString["id"].ToString();

            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand("select * from pizza where id=@id", con);

            cmd.Parameters.AddWithValue("@id", sid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();

            try
            {
                con.Open();
                da.Fill(dt);


            }
            // catch  {        }
            finally
            {

                con.Close();
            }

            img.Src = "img/" + dt.Rows[0][4];
            img2.Src = "img/" + dt.Rows[0][5];
            img3.Src = "img/" + dt.Rows[0][6];
            onvan.InnerHtml = dt.Rows[0][1].ToString();
            comb.InnerHtml = dt.Rows[0][3].ToString();
            //nafar.InnerHtml = dt.Rows[0][5].ToString();
            pr.Value = dt.Rows[0][2].ToString();
            //link.HRef = "order.aspx?title=" + dt.Rows[0][0].ToString();

        }

    }
}
