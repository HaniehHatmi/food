﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Web.UI.HtmlControls;
using System.Web.Configuration;

using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;

using System.IO;

namespace fasfood
{
    public partial class header : System.Web.UI.Page
    {
        string cs = WebConfigurationManager.ConnectionStrings["all"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

            SqlCommand cmd2 = new SqlCommand("select * from orderr", con);
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            DataSet ds2 = new DataSet();

            try
            {
                con.Open();
                da2.Fill(ds2);


            }
            finally
            {

                con.Close();
            }


            var x = ds2.Tables[0].Rows.Count;

            //HtmlGenericControl order = new HtmlGenericControl("div");
            //order.Attributes["class"] = "online";
            
            HtmlGenericControl order = new HtmlGenericControl("div");
            order.Attributes["class"] = "order";
            order.InnerHtml = "سبد خرید";
            order.Attributes["href"] = "order.aspx";


            //order.InnerHtml = x.ToString();

            orderBox.Controls.Add(order);



        }

    }
    }
}