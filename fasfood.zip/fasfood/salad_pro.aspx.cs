﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Web.UI.HtmlControls;
using System.Web.Configuration;

using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;

using System.IO;

namespace fasfood
{
    public partial class salad_pro : System.Web.UI.Page
    {
        string cs = WebConfigurationManager.ConnectionStrings["all"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand("select * from salad", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();

            try
            {
                con.Open();
                da.Fill(ds);

            }
            finally
            {
                con.Close();
            }

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                HtmlGenericControl item = new HtmlGenericControl("div");
                item.Attributes["class"] = "item";

                HtmlImage img = new HtmlImage();
                img.Attributes["src"] = "img/" + ds.Tables[0].Rows[i][4].ToString();

                HtmlGenericControl sp = new HtmlGenericControl("span");
                sp.InnerHtml = ds.Tables[0].Rows[i][1].ToString();

                HtmlAnchor menu = new HtmlAnchor();
                menu.Attributes["class"] = "manu";
                menu.InnerHtml = "مشاهده منو";
                menu.Attributes["href"] = "salad_pro.aspx?id=" + ds.Tables[0].Rows[i][0].ToString();

                HtmlGenericControl pr = new HtmlGenericControl("div");
                pr.Attributes["class"] = "price";
                pr.InnerHtml = ds.Tables[0].Rows[i][2].ToString() + "تومان";

                item.Controls.Add(img);
                item.Controls.Add(sp);
                item.Controls.Add(pr);
                item.Controls.Add(menu);

                otherproduct.Controls.Add(item);

            }
            string sid = Request.QueryString["id"];

            if (!Page.IsPostBack)
            {

                if (sid != null)
                {

                    fill_form();

                }
                else
                {
                    Form.InnerHtml = "داده نا موجود . . . ";
                }


            }


        }

        void fill_form()
        {
            string sid = Request.QueryString["id"].ToString();

            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand("select * from salad where id=@id", con);

            cmd.Parameters.AddWithValue("@id", sid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();

            try
            {
                con.Open();
                da.Fill(dt);

            }
            // catch  {        }
            finally
            {
                con.Close();
            }

            img.Src = "img/" + dt.Rows[0][4];
            img2.Src = "img/" + dt.Rows[0][5];
            img3.Src = "img/" + dt.Rows[0][6];
            onvan.Value = dt.Rows[0][1].ToString();
            comb.Value = dt.Rows[0][3].ToString();
            pr.Value = dt.Rows[0][2].ToString() + " تومان";


        }

    }
}
